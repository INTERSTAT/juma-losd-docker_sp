package ie.tcd.kdeg.r2rmleditor.pages;


public class Login extends org.tynamo.security.pages.Login {

}
